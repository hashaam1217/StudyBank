import React, { useState, useEffect, useRef } from 'react';
import './App.css';

interface Session {
  duration: number;
  timestamp: string;
  date: string;
}

interface StudyData {
  currentSessionSeconds: number;
  bankedSeconds: number;
  recreationSeconds: number;
  totalStudySeconds: number;
  sessions: Session[];
  lastStudyDate: string | null;
}

interface Achievement {
  title: string;
  desc: string;
}

function App() {
  const [data, setData] = useState<StudyData>({
    currentSessionSeconds: 0,
    bankedSeconds: 0,
    recreationSeconds: 0,
    totalStudySeconds: 0,
    sessions: [],
    lastStudyDate: null
  });

  const [elapsedTime, setElapsedTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [redeemInput, setRedeemInput] = useState('');
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [buttonFeedback, setButtonFeedback] = useState<{bank: boolean, redeem: boolean}>({
    bank: false,
    redeem: false
  });

  const timerInterval = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number>(0);

  // Load data from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('studyBankData');
    if (saved) {
      setData(JSON.parse(saved));
    }
  }, []);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('studyBankData', JSON.stringify(data));
  }, [data]);

  // Format seconds to HH:MM:SS
  const formatTime = (seconds: number): string => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  // Format seconds to hours with 1 decimal
  const formatHours = (seconds: number): string => {
    return (seconds / 3600).toFixed(1);
  };

  // Timer functions
  const startTimer = () => {
    if (isRunning) return;
    
    setIsRunning(true);
    startTimeRef.current = Date.now() - (elapsedTime * 1000);
    
    timerInterval.current = setInterval(() => {
      const newElapsed = Math.floor((Date.now() - startTimeRef.current) / 1000);
      setElapsedTime(newElapsed);
      setData(prev => ({ ...prev, currentSessionSeconds: newElapsed }));
    }, 100);
  };

  const pauseTimer = () => {
    if (!isRunning) return;
    
    setIsRunning(false);
    if (timerInterval.current) {
      clearInterval(timerInterval.current);
    }
  };

  const stopTimer = () => {
    if (elapsedTime === 0) return;
    
    setIsRunning(false);
    if (timerInterval.current) {
      clearInterval(timerInterval.current);
    }
    
    // Save session
    const session: Session = {
      duration: elapsedTime,
      timestamp: new Date().toISOString(),
      date: new Date().toLocaleDateString()
    };

    setData(prev => ({
      ...prev,
      sessions: [...prev.sessions, session],
      totalStudySeconds: prev.totalStudySeconds + elapsedTime,
      lastStudyDate: new Date().toDateString(),
      currentSessionSeconds: 0
    }));
    
    // Reset timer
    setElapsedTime(0);
    
    // Check achievements
    setTimeout(() => checkAchievements(session), 100);
  };

  const bankHours = () => {
    if (data.currentSessionSeconds === 0) {
      alert('No hours to bank! Complete a study session first.');
      return;
    }
    
    setData(prev => ({
      ...prev,
      bankedSeconds: prev.bankedSeconds + prev.currentSessionSeconds,
      currentSessionSeconds: 0
    }));
    
    // Visual feedback
    setButtonFeedback(prev => ({ ...prev, bank: true }));
    setTimeout(() => {
      setButtonFeedback(prev => ({ ...prev, bank: false }));
    }, 1500);
  };

  const redeemHours = () => {
    const hoursToRedeem = parseFloat(redeemInput);
    
    if (isNaN(hoursToRedeem) || hoursToRedeem <= 0) {
      alert('Please enter a valid number of hours.');
      return;
    }
    
    const secondsToRedeem = hoursToRedeem * 3600;
    
    if (secondsToRedeem > data.bankedSeconds) {
      alert('Insufficient banked hours!');
      return;
    }
    
    setData(prev => ({
      ...prev,
      bankedSeconds: prev.bankedSeconds - secondsToRedeem,
      recreationSeconds: prev.recreationSeconds + (secondsToRedeem * 0.4)
    }));
    
    setRedeemInput('');
    
    // Visual feedback
    setButtonFeedback(prev => ({ ...prev, redeem: true }));
    setTimeout(() => {
      setButtonFeedback(prev => ({ ...prev, redeem: false }));
    }, 1500);
  };

  const calculateStreak = (): number => {
    if (data.sessions.length === 0) return 0;
    
    let streak = 0;
    const today = new Date().toDateString();
    
    // Check if studied today
    if (data.lastStudyDate === today) {
      streak = 1;
    } else {
      return 0;
    }
    
    // Count backwards
    const checkDate = new Date();
    for (let i = 1; i < 365; i++) {
      checkDate.setDate(checkDate.getDate() - 1);
      const dateStr = checkDate.toDateString();
      const hasSession = data.sessions.some(s => new Date(s.timestamp).toDateString() === dateStr);
      
      if (hasSession) {
        streak++;
      } else {
        break;
      }
    }
    
    return streak;
  };

  const checkAchievements = (lastSession: Session) => {
    const newAchievements: Achievement[] = [];
    
    // First session
    if (data.sessions.length === 1) {
      newAchievements.push({
        title: '🎯 First Step',
        desc: 'Completed your first study session!'
      });
    }
    
    // 10 hours milestone
    const totalHours = data.totalStudySeconds / 3600;
    if (totalHours >= 10 && totalHours < 12) {
      newAchievements.push({
        title: '⭐ 10 Hour Club',
        desc: "You've studied for 10+ hours total!"
      });
    }
    
    // 7 day streak
    const streak = calculateStreak();
    if (streak === 7) {
      newAchievements.push({
        title: '🔥 Week Warrior',
        desc: '7 day study streak achieved!'
      });
    }
    
    // Long session (2+ hours)
    if (lastSession.duration >= 7200) {
      newAchievements.push({
        title: '💪 Marathon Mind',
        desc: 'Completed a 2+ hour study session!'
      });
    }
    
    setAchievements(newAchievements);
    
    // Clear achievements after 5 seconds
    setTimeout(() => setAchievements([]), 5000);
  };

  // Calculate metrics
  const avgSeconds = data.sessions.length > 0 ? data.totalStudySeconds / data.sessions.length : 0;
  const longestSeconds = data.sessions.length > 0 ? Math.max(...data.sessions.map(s => s.duration)) : 0;
  
  const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const weeklySeconds = data.sessions
    .filter(s => new Date(s.timestamp) > oneWeekAgo)
    .reduce((sum, s) => sum + s.duration, 0);
  
  const streak = calculateStreak();

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timerInterval.current) {
        clearInterval(timerInterval.current);
      }
    };
  }, []);

  return (
    <div className="app">
      <div className="container">
        <header>
          <h1>⚡ StudyBank</h1>
          <p className="tagline">Bank your focus. Earn your freedom.</p>
        </header>

        <div className="grid">
          {/* Timer Card */}
          <div className="card">
            <div className="card-title">
              <span className="emoji">⏱️</span>
              Study Timer
            </div>
            <div className={`timer-display ${isRunning ? 'running' : ''}`}>
              {formatTime(elapsedTime)}
            </div>
            <div className="button-group">
              <button 
                className="btn btn-primary" 
                onClick={startTimer}
                disabled={isRunning}
              >
                Start
              </button>
              <button 
                className="btn btn-secondary" 
                onClick={pauseTimer}
                disabled={!isRunning}
              >
                Pause
              </button>
              <button 
                className="btn btn-danger" 
                onClick={stopTimer}
                disabled={elapsedTime === 0}
              >
                Stop
              </button>
            </div>
            <div className="session-history">
              {data.sessions.slice(-5).reverse().map((session, idx) => (
                <div key={idx} className="session-item">
                  <span>{new Date(session.timestamp).toLocaleTimeString()}</span>
                  <span className="session-duration">{formatHours(session.duration)}h</span>
                </div>
              ))}
            </div>
          </div>

          {/* Banking Card */}
          <div className="card">
            <div className="card-title">
              <span className="emoji">🏦</span>
              Hour Bank
            </div>
            <div className="stat-group">
              <div className="stat">
                <div className="stat-label">Current Session</div>
                <div className="stat-value">{formatHours(data.currentSessionSeconds)}h</div>
              </div>
              <div className="stat">
                <div className="stat-label">Banked Hours</div>
                <div className="stat-value">{formatHours(data.bankedSeconds)}h</div>
              </div>
            </div>
            <button 
              className="btn btn-primary" 
              onClick={bankHours}
              style={{ width: '100%', marginTop: '1rem' }}
            >
              {buttonFeedback.bank ? '✅ Banked!' : '💰 Bank Current Session'}
            </button>

            <div style={{ marginTop: '2rem' }}>
              <div className="card-title" style={{ fontSize: '1.2rem' }}>
                <span className="emoji">🎮</span>
                Redeem Hours
              </div>
              <div className="multiplier-display">
                Redemption Rate: 0.4x (40%)
              </div>
              <div className="input-group">
                <label className="input-label">Hours to redeem:</label>
                <input 
                  type="number" 
                  className="input-field" 
                  placeholder="0.0" 
                  min="0" 
                  step="0.1"
                  value={redeemInput}
                  onChange={(e) => setRedeemInput(e.target.value)}
                />
              </div>
              <button 
                className="btn btn-primary" 
                onClick={redeemHours}
                style={{ width: '100%' }}
              >
                {buttonFeedback.redeem ? '🎉 Redeemed!' : '🎯 Redeem for Recreation Time'}
              </button>
              <div className="stat" style={{ marginTop: '1rem' }}>
                <div className="stat-label">Available Recreation</div>
                <div className="stat-value">{formatHours(data.recreationSeconds)}h</div>
              </div>
            </div>
          </div>

          {/* Metrics Card */}
          <div className="card">
            <div className="card-title">
              <span className="emoji">📊</span>
              Your Metrics
            </div>
            <div className="metrics-grid">
              <div className="metric-item">
                <span className="metric-name">Total Study Time</span>
                <span className="metric-value">{formatHours(data.totalStudySeconds)}h</span>
              </div>
              <div className="metric-item">
                <span className="metric-name">Total Sessions</span>
                <span className="metric-value">{data.sessions.length}</span>
              </div>
              <div className="metric-item">
                <span className="metric-name">Avg Session Length</span>
                <span className="metric-value">{formatHours(avgSeconds)}h</span>
              </div>
              <div className="metric-item">
                <span className="metric-name">Longest Session</span>
                <span className="metric-value">{formatHours(longestSeconds)}h</span>
              </div>
              <div className="metric-item">
                <span className="metric-name">This Week</span>
                <span className="metric-value">{formatHours(weeklySeconds)}h</span>
              </div>
              <div className="metric-item">
                <span className="metric-name">Study Streak</span>
                <span className="metric-value">{streak} days</span>
              </div>
            </div>

            <div className="achievement-area">
              {achievements.map((ach, idx) => (
                <div key={idx} className="achievement">
                  <div className="achievement-title">{ach.title}</div>
                  <div className="achievement-desc">{ach.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
